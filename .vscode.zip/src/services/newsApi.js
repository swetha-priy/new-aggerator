import axios from 'axios'

const API_KEY = import.meta.env.VITE_NEWS_API_KEY || ''
const BASE_URL = 'https://newsapi.org/v2'

const sampleData = {
  technology: [
    {
      id: 'tech-1',
      title: 'Indian IT Companies Lead Global AI Innovation',
      description: 'Major Indian tech firms announce breakthrough AI solutions, positioning India as a global leader in artificial intelligence.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
      publishedAt: new Date().toISOString(),
      source: { name: 'The Times of India Tech' }
    },
    {
      id: 'tech-2',
      title: 'India Launches 5G Services Across Major Cities',
      description: 'Reliance Jio and Airtel expand 5G network coverage, bringing high-speed internet to millions of Indian users.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800',
      publishedAt: new Date(Date.now() - 3600000).toISOString(),
      source: { name: 'The Hindu Business Line' }
    },
    {
      id: 'tech-3',
      title: 'Indian Startups Raise Record Funding in Tech Sector',
      description: 'Indian tech startups secure billions in funding, with fintech and edtech leading the investment surge.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800',
      publishedAt: new Date(Date.now() - 7200000).toISOString(),
      source: { name: 'Economic Times' }
    },
    {
      id: 'tech-4',
      title: 'Digital India Initiative Reaches New Milestone',
      description: 'Government announces expansion of digital services, bringing online facilities to remote villages across India.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800',
      publishedAt: new Date(Date.now() - 10800000).toISOString(),
      source: { name: 'NDTV Tech' }
    },
    {
      id: 'tech-5',
      title: 'Indian Software Engineers Lead Global Tech Innovation',
      description: 'Indian developers contribute to major open-source projects, with companies like Infosys and TCS leading digital transformation.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800',
      publishedAt: new Date(Date.now() - 14400000).toISOString(),
      source: { name: 'Mint Tech' }
    },
    {
      id: 'tech-6',
      title: 'UPI Transactions Cross 10 Billion Mark',
      description: 'India\'s Unified Payments Interface achieves record transaction volume, showcasing digital payment revolution.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800',
      publishedAt: new Date(Date.now() - 18000000).toISOString(),
      source: { name: 'Business Standard' }
    },
    {
      id: 'tech-7',
      title: 'Indian Space Tech: ISRO Launches New Satellite',
      description: 'Indian Space Research Organisation successfully launches communication satellite, advancing India\'s space capabilities.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800',
      publishedAt: new Date(Date.now() - 21600000).toISOString(),
      source: { name: 'The Indian Express' }
    },
    {
      id: 'tech-8',
      title: 'Make in India: Smartphone Manufacturing Booms',
      description: 'India becomes world\'s second-largest smartphone manufacturer, with local production reaching new heights.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1593508512255-86ab42c8a355?w=800',
      publishedAt: new Date(Date.now() - 25200000).toISOString(),
      source: { name: 'Hindustan Times Tech' }
    },
    {
      id: 'tech-9',
      title: 'Electric Vehicle Adoption Surges in India',
      description: 'EV sales in India reach record numbers as government incentives and charging infrastructure expand rapidly.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1593941707882-a5bac6861d75?w=800',
      publishedAt: new Date(Date.now() - 28800000).toISOString(),
      source: { name: 'Auto Car India' }
    },
    {
      id: 'tech-10',
      title: 'Indian E-commerce Giants Expand Services',
      description: 'Flipkart and Amazon India introduce new features, enhancing customer experience and delivery networks.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800',
      publishedAt: new Date(Date.now() - 32400000).toISOString(),
      source: { name: 'TechCrunch India' }
    }
  ],
  sports: [
    {
      id: 'sports-1',
      title: 'Indian Cricket Team Wins Series Against Australia',
      description: 'Team India clinches thrilling victory in the final test match, securing series win against Australia.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800',
      publishedAt: new Date().toISOString(),
      source: { name: 'ESPN Cricinfo' }
    },
    {
      id: 'sports-2',
      title: 'PV Sindhu Wins Badminton Championship',
      description: 'Indian badminton star PV Sindhu claims gold medal at international tournament, making the nation proud.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800',
      publishedAt: new Date(Date.now() - 3600000).toISOString(),
      source: { name: 'Sportskeeda' }
    },
    {
      id: 'sports-3',
      title: 'IPL Auction: Teams Bid for Top Players',
      description: 'Indian Premier League teams engage in intense bidding war for star players ahead of new season.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800',
      publishedAt: new Date(Date.now() - 7200000).toISOString(),
      source: { name: 'Cricbuzz' }
    },
    {
      id: 'sports-4',
      title: 'Indian Football Team Qualifies for Asian Cup',
      description: 'Blue Tigers secure qualification for AFC Asian Cup with impressive performance in qualifiers.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800',
      publishedAt: new Date(Date.now() - 10800000).toISOString(),
      source: { name: 'Goal India' }
    },
    {
      id: 'sports-5',
      title: 'Neeraj Chopra Wins Gold in Athletics Meet',
      description: 'Olympic champion javelin thrower Neeraj Chopra continues winning streak with another gold medal.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800',
      publishedAt: new Date(Date.now() - 14400000).toISOString(),
      source: { name: 'The Times of India Sports' }
    },
    {
      id: 'sports-6',
      title: 'Hockey India League Returns After Hiatus',
      description: 'Popular hockey league makes comeback, bringing top Indian and international players together.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1534158914592-062992fbe900?w=800',
      publishedAt: new Date(Date.now() - 18000000).toISOString(),
      source: { name: 'Hockey India' }
    },
    {
      id: 'sports-7',
      title: 'Indian Wrestlers Excel at World Championships',
      description: 'Indian wrestling contingent wins multiple medals, showcasing country\'s wrestling prowess.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=800',
      publishedAt: new Date(Date.now() - 21600000).toISOString(),
      source: { name: 'Wrestling Federation of India' }
    },
    {
      id: 'sports-8',
      title: 'Kabaddi World Cup: India Defends Title',
      description: 'Indian kabaddi team successfully defends world championship title with dominant performance.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1530549387789-4c1017266635?w=800',
      publishedAt: new Date(Date.now() - 25200000).toISOString(),
      source: { name: 'Pro Kabaddi League' }
    },
    {
      id: 'sports-9',
      title: 'Indian Chess Grandmaster Wins Tournament',
      description: 'Young Indian chess prodigy defeats world champion, marking historic victory for Indian chess.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800',
      publishedAt: new Date(Date.now() - 28800000).toISOString(),
      source: { name: 'Chess.com India' }
    },
    {
      id: 'sports-10',
      title: 'Indian Athletes Prepare for Asian Games',
      description: 'Indian contingent gears up for Asian Games with intensive training and preparation camps.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800',
      publishedAt: new Date(Date.now() - 32400000).toISOString(),
      source: { name: 'Indian Olympic Association' }
    }
  ],
  entertainment: [
    {
      id: 'ent-1',
      title: 'Bollywood Blockbuster Breaks Box Office Records',
      description: 'Latest Hindi film crosses 500 crore mark, becoming one of the highest-grossing Indian films of all time.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800',
      publishedAt: new Date().toISOString(),
      source: { name: 'Filmfare' }
    },
    {
      id: 'ent-2',
      title: 'Indian Music Artists Dominate Global Charts',
      description: 'Indian musicians and singers achieve international recognition with chart-topping hits on global platforms.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800',
      publishedAt: new Date(Date.now() - 3600000).toISOString(),
      source: { name: 'Radio Mirchi' }
    },
    {
      id: 'ent-3',
      title: 'OTT Platform Releases Highly Anticipated Web Series',
      description: 'Popular streaming service launches new original series featuring top Indian actors and directors.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800',
      publishedAt: new Date(Date.now() - 7200000).toISOString(),
      source: { name: 'OTT India' }
    },
    {
      id: 'ent-4',
      title: 'Filmfare Awards: Bollywood Celebrates Excellence',
      description: 'Annual Filmfare Awards ceremony honors best performances in Hindi cinema with star-studded event.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800',
      publishedAt: new Date(Date.now() - 10800000).toISOString(),
      source: { name: 'Filmfare' }
    },
    {
      id: 'ent-5',
      title: 'Indian Classical Music Festival Draws Global Audience',
      description: 'Renowned Indian musicians perform at prestigious music festival, showcasing rich cultural heritage.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800',
      publishedAt: new Date(Date.now() - 14400000).toISOString(),
      source: { name: 'The Hindu' }
    },
    {
      id: 'ent-6',
      title: 'Stand-up Comedy Scene Thrives in India',
      description: 'Indian comedians gain international recognition with sold-out shows and viral specials on streaming platforms.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1501386761578-5ad32b3d0b88?w=800',
      publishedAt: new Date(Date.now() - 18000000).toISOString(),
      source: { name: 'Comedy Central India' }
    },
    {
      id: 'ent-7',
      title: 'Indian Gaming Industry Sees Massive Growth',
      description: 'Mobile gaming and esports in India reach new heights with record user engagement and investments.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800',
      publishedAt: new Date(Date.now() - 21600000).toISOString(),
      source: { name: 'IGN India' }
    },
    {
      id: 'ent-8',
      title: 'Theater Festival Showcases Indian Dramas',
      description: 'National theater festival brings together best Indian plays and performances from across the country.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1503095396549-807759245b35?w=800',
      publishedAt: new Date(Date.now() - 25200000).toISOString(),
      source: { name: 'The Indian Express' }
    },
    {
      id: 'ent-9',
      title: 'Indian Podcasts Gain Global Listenership',
      description: 'Hindi and regional language podcasts attract millions of listeners, revolutionizing audio content in India.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800',
      publishedAt: new Date(Date.now() - 28800000).toISOString(),
      source: { name: 'Spotify India' }
    },
    {
      id: 'ent-10',
      title: 'Indian Art Exhibition Opens in International Museum',
      description: 'Contemporary Indian art gains global recognition with major exhibition featuring works from renowned artists.',
      url: '#',
      urlToImage: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800',
      publishedAt: new Date(Date.now() - 32400000).toISOString(),
      source: { name: 'NDTV Culture' }
    }
  ]
}

export const fetchNewsByCategory = async (category = 'technology') => {
  if (API_KEY) {
    try {
      const categoryQueries = {
        technology: 'technology OR AI OR software',
        sports: 'sports OR cricket OR football',
        entertainment: 'entertainment OR movies OR bollywood'
      }

      const searchQuery = categoryQueries[category] || category
      const response = await axios.get(`${BASE_URL}/everything`, {
        params: {
          q: searchQuery,
          sortBy: 'publishedAt',
          language: 'en',
          apiKey: API_KEY,
          pageSize: 50
        }
      })

      if (response.data.articles && response.data.articles.length > 0) {
        return response.data.articles.map((article, index) => ({
          id: `${category}-${index}-${Date.now()}`,
          title: article.title,
          description: article.description,
          url: article.url,
          urlToImage: article.urlToImage,
          publishedAt: article.publishedAt,
          source: article.source
        }))
      } else {
        console.warn('No articles found from API, using sample data')
        return sampleData[category] || []
      }
    } catch (error) {
      console.error('Error fetching news:', error.message)
      console.log('Using sample data for category:', category)
      return sampleData[category] || []
    }
  }

  await new Promise(resolve => setTimeout(resolve, 500))
  console.log('No API key found, using sample data for category:', category)
  return sampleData[category] || []
}

export const searchNews = async (query) => {
  if (API_KEY) {
    try {
      const response = await axios.get(`${BASE_URL}/everything`, {
        params: {
          q: query,
          sortBy: 'publishedAt',
          apiKey: API_KEY,
          pageSize: 50
        }
      })
      return response.data.articles.map((article, index) => ({
        id: `search-${index}-${Date.now()}`,
        title: article.title,
        description: article.description,
        url: article.url,
        urlToImage: article.urlToImage,
        publishedAt: article.publishedAt,
        source: article.source
      }))
    } catch (error) {
      console.error('Error searching news:', error)
      return []
    }
  }
  
  // Return empty for search if no API key
  return []
}

