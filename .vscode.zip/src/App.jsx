import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Header from './components/Header'
import NewsFeed from './components/NewsFeed'
import Favorites from './components/Favorites'
import './App.css'

function App() {
  const [favorites, setFavorites] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('favorites')
      const parsed = saved ? JSON.parse(saved) : []
      // Debug: Log initial favorites load
      if (process.env.NODE_ENV === 'development') {
        console.log('🚀 App initialized')
        console.log('💾 Loaded favorites from localStorage:', parsed.length)
      }
      return parsed
    }
    return []
  })

  const addToFavorites = (article) => {
    const newFavorites = [...favorites, article]
    setFavorites(newFavorites)
    localStorage.setItem('favorites', JSON.stringify(newFavorites))
    // Dispatch custom event to update header
    window.dispatchEvent(new Event('favoritesUpdated'))
    // Debug: Log when article is added
    if (process.env.NODE_ENV === 'development') {
      console.log('✅ Article added to favorites:', article.title)
      console.log('📊 Total favorites:', newFavorites.length)
    }
  }

  const removeFromFavorites = (articleId) => {
    const article = favorites.find(fav => fav.id === articleId)
    const newFavorites = favorites.filter(article => article.id !== articleId)
    setFavorites(newFavorites)
    localStorage.setItem('favorites', JSON.stringify(newFavorites))
    // Dispatch custom event to update header
    window.dispatchEvent(new Event('favoritesUpdated'))
    // Debug: Log when article is removed
    if (process.env.NODE_ENV === 'development') {
      console.log('❌ Article removed from favorites:', article?.title || articleId)
      console.log('📊 Total favorites:', newFavorites.length)
    }
  }

  const isFavorite = (articleId) => {
    return favorites.some(article => article.id === articleId)
  }

  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route 
            path="/" 
            element={
              <NewsFeed 
                addToFavorites={addToFavorites}
                removeFromFavorites={removeFromFavorites}
                isFavorite={isFavorite}
              />
            } 
          />
          <Route 
            path="/favorites" 
            element={
              <Favorites 
                favorites={favorites}
                removeFromFavorites={removeFromFavorites}
              />
            } 
          />
          <Route 
            path="/offline" 
            element={
              <Favorites 
                favorites={favorites}
                removeFromFavorites={removeFromFavorites}
              />
            } 
          />
        </Routes>
      </div>
    </Router>
  )
}

export default App

