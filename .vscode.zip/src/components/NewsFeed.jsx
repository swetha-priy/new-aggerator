import React, { useState, useEffect } from 'react'
import { fetchNewsByCategory, searchNews } from '../services/newsApi'
import NewsCard from './NewsCard'
import './NewsFeed.css'

const NewsFeed = ({ addToFavorites, removeFromFavorites, isFavorite }) => {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState('technology')
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)

  const categories = [
    { id: 'technology', name: 'Technology', icon: '💻' },
    { id: 'sports', name: 'Sports', icon: '⚽' },
    { id: 'entertainment', name: 'Entertainment', icon: '🎬' }
  ]

  useEffect(() => {
    loadNews(activeCategory)
  }, [activeCategory])

  const loadNews = async (category) => {
    setLoading(true)
    setIsSearching(false)
    try {
      if (process.env.NODE_ENV === 'development') {
        console.log('📰 Loading news for category:', category)
      }
      const news = await fetchNewsByCategory(category)
      setArticles(news)
      if (process.env.NODE_ENV === 'development') {
        console.log('✅ News loaded successfully:', news.length, 'articles')
      }
    } catch (error) {
      console.error('❌ Error loading news:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!searchQuery.trim()) {
      loadNews(activeCategory)
      return
    }

    setLoading(true)
    setIsSearching(true)
    try {
      if (process.env.NODE_ENV === 'development') {
        console.log('🔍 Searching for:', searchQuery)
      }
      const results = await searchNews(searchQuery)
      setArticles(results)
      if (process.env.NODE_ENV === 'development') {
        console.log('✅ Search results:', results.length, 'articles found')
      }
    } catch (error) {
      console.error('❌ Error searching news:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCategoryChange = (category) => {
    setActiveCategory(category)
    setSearchQuery('')
  }

  return (
    <div className="news-feed">
      <div className="news-container">
        <div className="feed-header">
          <h2>Latest News</h2>
          <form onSubmit={handleSearch} className="search-form">
            <input
              type="text"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
            <button type="submit" className="search-button">
              Search
            </button>
          </form>
        </div>

        <div className="category-tabs">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => handleCategoryChange(category.id)}
              className={`category-tab ${activeCategory === category.id ? 'active' : ''}`}
            >
              <span className="category-icon">{category.icon}</span>
              {category.name}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading latest news...</p>
          </div>
        ) : articles.length === 0 ? (
          <div className="no-results">
            <p>No articles found. Try a different search or category.</p>
          </div>
        ) : (
          <>
            {isSearching && (
              <div className="search-info">
                <p>Search results for: <strong>"{searchQuery}"</strong></p>
                <button onClick={() => { setSearchQuery(''); loadNews(activeCategory); }} className="clear-search">
                  Clear Search
                </button>
              </div>
            )}
            <div className="articles-grid">
              {articles.map(article => (
                <NewsCard
                  key={article.id}
                  article={article}
                  addToFavorites={addToFavorites}
                  removeFromFavorites={removeFromFavorites}
                  isFavorite={isFavorite(article.id)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export default NewsFeed

