import React, { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import './Header.css'

const Header = () => {
  const location = useLocation()
  const [favoritesCount, setFavoritesCount] = useState(0)

  useEffect(() => {
    const updateFavoritesCount = () => {
      try {
        if (typeof window !== 'undefined') {
          const favorites = JSON.parse(localStorage.getItem('favorites') || '[]')
          setFavoritesCount(favorites.length)
        }
      } catch (error) {
        console.error('Error reading favorites:', error)
        setFavoritesCount(0)
      }
    }

    updateFavoritesCount()
    
    // Listen for storage changes (when favorites are updated in other tabs)
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', updateFavoritesCount)
      // Custom event for same-tab updates
      window.addEventListener('favoritesUpdated', updateFavoritesCount)
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('storage', updateFavoritesCount)
        window.removeEventListener('favoritesUpdated', updateFavoritesCount)
      }
    }
  }, [])

  // Update count when route changes (in case favorites were updated)
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        const favorites = JSON.parse(localStorage.getItem('favorites') || '[]')
        setFavoritesCount(favorites.length)
      }
    } catch (error) {
      console.error('Error reading favorites:', error)
      setFavoritesCount(0)
    }
  }, [location])

  return (
    <header className="header">
      <div className="header-container">
        <Link to="/" className="logo">
          <h1>📰 News Aggregator</h1>
        </Link>
        <nav className="nav">
          <Link 
            to="/" 
            className={location.pathname === '/' ? 'nav-link active' : 'nav-link'}
          >
            Home
          </Link>
          <Link 
            to="/offline" 
            className={location.pathname === '/favorites' || location.pathname === '/offline' ? 'nav-link active' : 'nav-link'}
            title="Direct link to offline news"
          >
            📱 Offline ({favoritesCount})
          </Link>
        </nav>
      </div>
    </header>
  )
}

export default Header

