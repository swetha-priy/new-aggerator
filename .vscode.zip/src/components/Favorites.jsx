import React, { useState, useEffect } from 'react'
import NewsCard from './NewsCard'
import './Favorites.css'

const Favorites = ({ favorites, removeFromFavorites }) => {
  const [filteredFavorites, setFilteredFavorites] = useState(favorites)
  const [searchQuery, setSearchQuery] = useState('')
  const [showStorageInfo, setShowStorageInfo] = useState(false)

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = favorites.filter(article =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.description?.toLowerCase().includes(searchQuery.toLowerCase())
      )
      setFilteredFavorites(filtered)
    } else {
      setFilteredFavorites(favorites)
    }
  }, [searchQuery, favorites])

  const addToFavorites = () => {
    // This is a no-op since we're already in favorites
  }

  const isFavorite = () => true

  return (
    <div className="favorites-page">
      <div className="favorites-container">
        <div className="favorites-header">
          <h2>Your Favorites</h2>
          <p className="favorites-subtitle">
            {favorites.length === 0 
              ? 'No saved articles yet. Start adding articles to your favorites!'
              : `You have ${favorites.length} saved article${favorites.length !== 1 ? 's' : ''}`
            }
          </p>
          {favorites.length > 0 && (
            <div className="favorites-search">
              <input
                type="text"
                placeholder="Search your favorites..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="favorites-search-input"
              />
            </div>
          )}
        </div>

        {favorites.length === 0 ? (
          <div className="empty-favorites">
            <div className="empty-icon" aria-hidden="true"></div>
            <h3>No Favorites Yet</h3>
            <p>Browse news articles and click the heart icon to save them for offline reading.</p>
          </div>
        ) : filteredFavorites.length === 0 ? (
          <div className="no-results">
            <p>No favorites match your search query.</p>
          </div>
        ) : (
          <div className="favorites-grid">
            {filteredFavorites.map(article => (
              <NewsCard
                key={article.id}
                article={article}
                addToFavorites={addToFavorites}
                removeFromFavorites={removeFromFavorites}
                isFavorite={isFavorite()}
              />
            ))}
          </div>
        )}

        {favorites.length > 0 && (
          <>
            <div className="offline-info">
              <div className="offline-badge" aria-hidden="true"></div>
              <div className="offline-text">
                <h4>Offline Access</h4>
                <p>All your favorite articles are saved locally and available offline. You can read them anytime, even without an internet connection!</p>
                <button 
                  className="storage-info-toggle"
                  onClick={() => setShowStorageInfo(!showStorageInfo)}
                >
                  {showStorageInfo ? '▼ Hide' : '▶ Show'} Storage Location
                </button>
              </div>
            </div>
            
            {showStorageInfo && (
              <div className="storage-info">
                <div className="storage-info-header">
                  <span className="storage-icon" aria-hidden="true"></span>
                  <h4>Where Your Data is Stored</h4>
                </div>
                <div className="storage-details">
                  <div className="storage-item">
                    <strong>Storage Type:</strong> Browser LocalStorage
                  </div>
                  <div className="storage-item">
                    <strong>Storage Key:</strong> <code>'favorites'</code>
                  </div>
                  <div className="storage-item">
                    <strong>Location:</strong> Browser's Local Storage for <code>http://localhost:5173</code>
                  </div>
                  <div className="storage-item">
                    <strong>How to View:</strong>
                    <ol>
                      <li>Open DevTools (Press <kbd>F12</kbd>)</li>
                      <li>Go to <strong>Application</strong> tab (Chrome) or <strong>Storage</strong> tab (Firefox)</li>
                      <li>Expand <strong>Local Storage</strong> → <code>http://localhost:5173</code></li>
                      <li>Find the <code>'favorites'</code> key</li>
                    </ol>
                  </div>
                  <div className="storage-item">
                    <strong>Data Format:</strong> JSON array of article objects
                  </div>
                  <div className="storage-note">
                    <span className="note-icon" aria-hidden="true"></span>
                    <p>Your data persists in your browser until you clear browser data or localStorage. It's available even when offline!</p>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default Favorites

