import React, { useState } from 'react'
import './NewsCard.css'

const NewsCard = ({ article, addToFavorites, removeFromFavorites, isFavorite }) => {
  const handleFavoriteClick = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (isFavorite) {
      removeFromFavorites(article.id)
    } else {
      addToFavorites(article)
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return 'Just now'
    if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`
    const diffInDays = Math.floor(diffInHours / 24)
    return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`
  }

  const [imgLoading, setImgLoading] = useState(true)

  return (
    <article className="news-card">
      <div className="card-image-container">
        <img 
          src={article.urlToImage || 'https://via.placeholder.com/400x250?text=No+Image'}
          alt={article.title}
          className={`card-image ${imgLoading ? 'loading' : ''}`}
          loading="lazy"
          onLoad={() => setImgLoading(false)}
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/400x250?text=No+Image'
            setImgLoading(false)
          }}
        />
        <div className="card-image-placeholder" aria-hidden="true"></div>
        <button
          onClick={handleFavoriteClick}
          className={`favorite-button ${isFavorite ? 'active' : ''}`}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <path d="M12 21s-7-4.35-9-6.58C1.5 11.7 3.5 7 7.5 7c2.04 0 3.18 1.07 4.5 2.5C13.32 8.07 14.46 7 16.5 7 20.5 7 22.5 11.7 21 14.42 19 16.65 12 21 12 21z" />
          </svg>
        </button>
      </div>
      <div className="card-content">
        <div className="card-meta">
          <span className="card-source">{article.source?.name || 'Unknown Source'}</span>
          <span className="card-date">{formatDate(article.publishedAt)}</span>
        </div>
        <h3 className="card-title">{article.title}</h3>
        <p className="card-description">
          {article.description || 'No description available.'}
        </p>
        {article.url && article.url !== '#' ? (
          <a 
            href={article.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="card-link"
            onClick={() => console.log('Opening URL:', article.url)}
          >
            Read More →
          </a>
        ) : (
          <span className="card-link" style={{opacity: 0.5, cursor: 'default'}}>
            No URL Available
          </span>
        )}
      </div>
    </article>
  )
}

export default NewsCard

